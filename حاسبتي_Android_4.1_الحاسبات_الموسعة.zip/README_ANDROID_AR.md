# حاسبتي — نسخة Android 4.1

هذا المشروع جاهز للبناء إلى APK عبر GitHub Actions، ولا يحتاج Android Studio على الهاتف.

## المطلوب منك
1. أنشئ مستودعًا جديدًا على GitHub باسم `hasibati-android`.
2. ارفع **محتويات هذا المجلد** إلى المستودع، وليس ملف ZIP نفسه.
3. تأكد أن مجلد `.github/workflows` موجود في جذر المستودع.
4. افتح **Actions** ثم **Build Hasibati Android**.
5. اضغط **Run workflow**.
6. بعد ظهور علامة النجاح، افتح نتيجة التشغيل ثم **Artifacts**.
7. حمّل `hasibati-debug-apk` وفك الضغط، وستجد `app-debug.apk`.

## إذا كنت تستخدم الهاتف فقط
يمكن رفع الملفات من متصفح GitHub. إذا كان اختيار المجلدات صعبًا على الهاتف، ارفع الملفات الأساسية أولًا ثم أنشئ المجلدات المطلوبة من محرر GitHub:

- `.github/workflows/build-apk.yml`
- `app/build.gradle`
- `app/src/main/AndroidManifest.xml`
- `app/src/main/java/com/hasibati/app/MainActivity.java`
- `app/src/main/res/values/styles.xml`
- `app/src/main/assets/index.html`
- `build.gradle`
- `settings.gradle`
- `gradle.properties`
- `.gitignore`

## النسخة الناتجة
هذه مرحلة اختبار Debug. بعد التأكد أن التطبيق يعمل على الهاتف، نجهز Release موقعة وAAB للنشر.
